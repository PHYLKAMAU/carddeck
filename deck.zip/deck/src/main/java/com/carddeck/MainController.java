package com.carddeck;

import javafx.concurrent.Service;
import javafx.concurrent.Task;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

import java.io.IOException;
import java.util.List;

public class MainController {

    @FXML
    private Label cardLabel;

    @FXML
    private ImageView cardImage;

    @FXML
    private Button drawCardButton;

    @FXML
    private void handleAPICallButton() {
        try {
            List<Card> cards = CardService.drawCards();
            if (!cards.isEmpty()) {
                Card card = cards.get(0);
                cardLabel.setText(card.getValue() + " of " + card.getSuit());
                cardImage.setImage(new Image(card.getImage()));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

