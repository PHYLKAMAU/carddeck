package com.carddeck;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.IOException;
import java.net.URL;
import java.util.List;

public class CardService {

    private static final String API_URL = "https://deckofcardsapi.com/api/deck/rplrhm8jkmq6/draw/?count=2";

    public static List<Card> drawCards() throws IOException {
        ObjectMapper objectMapper = new ObjectMapper();
        JsonNode response = objectMapper.readTree(new URL(API_URL));
        return objectMapper.readerForListOf(Card.class).readValue(response.get("cards"));
    }
}
