module com.example.deck {
    requires javafx.controls;
    requires javafx.fxml;
    requires com.fasterxml.jackson.databind;


    opens com.example.deck to javafx.fxml;
    exports com.example.deck;
}